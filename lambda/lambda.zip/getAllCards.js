'use strict';
 
var pg = require('pg');
 
exports.handler = function(event, context) {   
 
    var dbConfig = {
        user: 'mtgDraftWizard',
        password: 'mtgDraftWizard',
        database: 'mtgDraftWizard',
        host: 'mtgdraftwizard.cl9vld98bzfr.ap-southeast-2.rds.amazonaws.com',
        port: 5432
    };
    var client = new pg.Client(dbConfig);
    client.connect((err) => {
        if (err) {
            return console.log("Something broke: " + err);
        }
    })

    const query = client.query('SELECT * FROM card');

    // Stream results back one row at a time
    query.on('row', (row) => {
        results.push(row);
    });
    // After all data is returned, close connection and return results
    query.on('end', function() {
        done();
        return res.json(results);
    });  
    
    client.end();
 };